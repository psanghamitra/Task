﻿using Microsoft.AspNetCore.Mvc;
using MVCandOOPfundamentals;

namespace MVCandOOPfundamentals
{
 
    public class OfferServiceController : Controller
    {
        List<Offer> listOffer = new List<Offer>();
        List<Product> listProduct = new List<Product>();

        public readonly Product _product;
        public OfferServiceController(Product product)
        {
            _product = product;
            listProduct.Add(new Product
            {
                ProductName = "P1",
                Price = 1000,
                Description = "p1 desc"
            });
            listProduct.Add(new Product
            {
                ProductName = "P2",
                Price = 200,
                Description = "p2 desc"
            });
            listProduct.Add(new Product
            {
                ProductName = "P3",
                Price = 400,
                Description = "p3 desc"
            });
            listProduct.Add(new Product
            {
                ProductName = "P4",
                Price = 700,
                Description = "p4 desc"
            });
            listProduct.Add(new Product
            {
                ProductName = "P5",
                Price = 600,
                Description = "p5 desc"
            });
            listProduct.Add(new Product
            {
                ProductName = "P6",
                Price = 800,
                Description = "p6 desc"
            });
            listOffer.Add(
                new Offer
                {
                    OfferName= "ComboPackage1",
                }
                );
            listOffer.Add(
               new Offer
               {
                   OfferName = "ComboPackage2",
               }
               );
            listOffer.Add(
               new Offer
               {
                   OfferName = "ComboPackage3",
               }
               );
            listOffer.Add(
               new Offer
               {
                   OfferName = "ComboPackage4",
               }
               );
        }
        
        public IActionResult Index()
        {
           

            return View();
        }
        [HttpGet]
        public List<Product> GetProducts() 
        {
            return listProduct;
         
        }

        [HttpGet]
        public List<Product> GetTodayOffers()
        {
            return listProduct.OrderByDescending(y=>y.Price).Take(3).ToList();

        }

        [HttpGet]
        public List<Product> GetAllSecondLowestOffers()
        {
            return listProduct.OrderByDescending(y => y.Price).Skip(1).Take(1).ToList();

        }
        [HttpPost]
        public bool insertProduct(Product product)
        {
            try
            {
                listProduct.Add(product);
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
        public List<Offer> GetOfferList(string offer)
        {

            return listOffer;
        }
    }
}
