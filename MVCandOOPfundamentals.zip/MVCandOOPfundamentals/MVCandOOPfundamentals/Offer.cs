﻿namespace MVCandOOPfundamentals
{
    public class Offer
    {
        public string OfferName { get; set; }
        public ICollection<Product> listProducts { get; set; }
}
}
