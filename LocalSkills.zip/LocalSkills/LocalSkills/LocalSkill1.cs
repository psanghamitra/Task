﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LocalSkills
{
    internal class LocalSkill1
    {
        public void PrintValues()
        {
//            1) Write a program that loops through[1..100]. It should do the following:
//a) If the number is divisible by 3, print “fizz”.
//b) If divisible by 5 print “buzz”.
//c) If divisible by 3 & 5, print “fizzbuzz”.
            for (int i = 1; i < 100; i++) {
                if (i % 3 == 0 && i % 5 == 0)
                {
                    Console.WriteLine("fizzbuzz");
                }
                else if (i % 3 == 0)
                {
                    Console.WriteLine("fizz");
                }
                else if(i % 5 == 0)
                {
                    Console.WriteLine("buzz");
                }
            
            }

//            Write a program to reverse a string “abcdef” --> “fedcba” without using the.NET
//reverse() function
//Prompt for the input from console and display the output to the console.

            string s = "abcdef";
            string result = "";
            char[] chars = s.ToCharArray();
            for (int i = chars.Length-1; i > -1; i--) {
                result= result + chars[i];
            }
            Console.WriteLine(result);
        }
    }
}
