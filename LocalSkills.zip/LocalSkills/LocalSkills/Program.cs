﻿// See https://aka.ms/new-console-template for more information
using LocalSkills;

Console.WriteLine("Hello, World!");
LocalSkill1 localSkill1 = new LocalSkill1();
localSkill1.PrintValues();